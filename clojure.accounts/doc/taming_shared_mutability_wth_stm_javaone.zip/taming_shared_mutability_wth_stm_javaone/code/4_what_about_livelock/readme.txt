There is potential live lock in the code. A thread may wait for a long time to get
the lock. This is not good. We can't quite timeout of a blocked synchronized.
We would have to use Lock interface and the tryLock method with timeout. This
only makes the more complex, hard to understand, and hard to maintain.