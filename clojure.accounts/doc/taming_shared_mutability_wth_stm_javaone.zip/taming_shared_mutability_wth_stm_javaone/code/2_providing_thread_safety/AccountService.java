public class AccountService {
  public static void transfer(
      final Account from, final Account to, final int amount) {

    synchronized (from) {
      synchronized (to) {
        if(from.withdraw(amount))
          to.deposit(amount);
      }
    }
  }
}