public class Sample {
  public static void main(String[] args) {
    Account account1 = new Account(1000);
    Account account2 = new Account(1000);

    AccountService.transfer(account1, account2, 5000);
    System.out.println(account1.getBalance());
    System.out.println(account2.getBalance());
  }
}
/*
oops: java.lang.RuntimeException: No luck
1000
1000
*/