public class Account implements Comparable<Account> {
  private int balance;
  
  public Account(final int initialBalance) {
    balance = initialBalance;
  }
  
  public synchronized void deposit(final int amount) {
    if(amount > 0)
      balance += amount;
  }
  
  public synchronized boolean withdraw(final int amount) {
    if(amount > 0 && balance >= amount) {
      balance -= amount;
      return true;
    }
    return false;
  }

  public synchronized int getBalance() { return balance; }

  @Override
  public int compareTo(Account o) {
    return hashCode(); //need to enforce an ordering here...
  }
}