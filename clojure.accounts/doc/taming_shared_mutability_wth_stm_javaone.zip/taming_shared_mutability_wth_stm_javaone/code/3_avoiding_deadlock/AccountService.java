import java.util.Arrays;

public class AccountService {
  public static void transfer(
      final Account from, final Account to, final int amount) {

    Account[] accounts = new Account[] {from, to};
    Arrays.sort(accounts);
    synchronized (accounts[0]) {
      synchronized (accounts[1]) {
        if(from.withdraw(amount))
          to.deposit(amount);
      }
    }
  }
}