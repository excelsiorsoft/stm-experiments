public class Sample {
  public static void main(String[] args) {
    Account account1 = new Account(1000);
    Account account2 = new Account(1000);

    AccountService.transfer(account1, account2, 500);
    System.out.println(account1.getBalance());
    System.out.println(account2.getBalance());
  }
}

/*
Exception in thread "main" java.lang.IllegalStateException: No transaction running
	at clojure.lang.LockingTransaction.getEx(LockingTransaction.java:208)
	at clojure.lang.Ref.set(Ref.java:165)
	at Account.deposit(Account.java:13)
	at AccountService.transfer(AccountService.java:5)
	at Sample.main(Sample.java:6)
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:57)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:601)
	at com.intellij.rt.execution.application.AppMain.main(AppMain.java:120)
*/