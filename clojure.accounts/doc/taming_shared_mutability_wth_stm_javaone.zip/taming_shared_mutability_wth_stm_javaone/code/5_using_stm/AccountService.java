public class AccountService {
  public static void transfer(
      final Account from, final Account to, final int amount) {

    to.deposit(amount);
    from.withdraw(amount);
  }
}