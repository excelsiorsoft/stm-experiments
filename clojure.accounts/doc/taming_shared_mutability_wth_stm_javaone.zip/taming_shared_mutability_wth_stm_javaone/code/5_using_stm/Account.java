//need clojure.jar in the classpath to use this.
import clojure.lang.Ref;

public class Account  {
  private Ref balance;
  
  public Account(final int initialBalance) {
    balance = new Ref(initialBalance);
  }
  
  public void deposit(final int amount) {
    if(amount > 0)
      balance.set(getBalance() + amount);
  }
  
  public boolean withdraw(final int amount) {
    if(amount > 0 && getBalance() >= amount) {
      balance.set(getBalance() - amount);
      return true;
    }
    return false;
  }

  public int getBalance() { return (Integer) balance.deref(); }
}